import java.util.ArrayList;
import java.util.Scanner;

class Message {
    String messageId;
    String sender;
    String recipient;
    String content;

    public Message(String messageId, String sender, String recipient, String content) {
        this.messageId = messageId;
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;
    }

    public String getHash() {
        return Integer.toHexString((messageId + sender + recipient + content).hashCode());
    }

    @Override
    public String toString() {
        return "Message ID: " + messageId + "\nSender: " + sender + "\nRecipient: " + recipient + 
               "\nContent: " + content + "\nHash: " + getHash() + "\n";
    }
}

public class MessageApp {
    static ArrayList<Message> messages = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        // Sample messages
        messages.add(new Message("M001", "Goodness", "+27834557896", "Did you get the cake?"));
        messages.add(new Message("M002", "Aubreyy", "+27838884567", "Where are you? You are late! I have asked you to be on time."));
        messages.add(new Message("M003", "Prince", "+27834484567", "Yohoooo, I am at your gate."));
        messages.add(new Message("M004", "Aubreyy", "0838884567", "It is dinner time!"));
        messages.add(new Message("M005", "Prince", "+27838884567", "Ok, I am leaving without you."));

        
        
        
        while (running) {
            System.out.println("\nMenu:");
            System.out.println("1. Display all sender and recipient pairs");
            System.out.println("2. Display the longest message");
            System.out.println("3. Search by Message ID");
            System.out.println("4. Search messages by Recipient");
            System.out.println("5. Delete message by Hash");
            System.out.println("6. Display full message report");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            
            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 1:
                    for (Message m : messages) {
                        System.out.println("Sender: " + m.sender + " -> Recipient: " + m.recipient);
                    }
                    break;

                case 2:
                    Message longest = null;
                    for (Message m : messages) {
                        if (longest == null || m.content.length() > longest.content.length()) {
                            longest = m;
                        }
                    }
                    System.out.println("Longest Message:\n" + (longest != null ? longest : "No messages found."));
                    break;

                case 3:
                    System.out.print("Enter Message ID: ");
                    String idSearch = scanner.nextLine();
                    boolean found = false;
                    for (Message m : messages) {
                        if (m.messageId.equals(idSearch)) {
                            System.out.println("Recipient: " + m.recipient);
                            System.out.println("Message: " + m.content);
                            found = true;
                            break;
                        }
                    }
                    if (!found) System.out.println("Message ID not found.");
                    break;

                case 4:
                    System.out.print("Enter Recipient Name: ");
                    String recipientSearch = scanner.nextLine();
                    for (Message m : messages) {
                        if (m.recipient.equalsIgnoreCase(recipientSearch)) {
                            System.out.println(m);
                        }
                    }
                    break;

                case 5:
                    System.out.print("Enter Message Hash: ");
                    String hash = scanner.nextLine();
                    boolean removed = messages.removeIf(m -> m.getHash().equals(hash));
                    System.out.println(removed ? "Message deleted." : "No message found with given hash.");
                    break;

                case 6:
                    System.out.println("Message Report:");
                    for (Message m : messages) {
                        System.out.println(m);
                    }
                    break;

                case 7:
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }
        scanner.close();
    }
}
                