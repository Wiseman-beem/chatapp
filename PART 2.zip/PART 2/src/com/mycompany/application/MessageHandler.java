package com.mycompany.application;

import javax.swing.JOptionPane;

public class MessageHandler {

    public void startMessaging(String username) {
        boolean exit = false;

        JOptionPane.showMessageDialog(null, "--- Messaging ---\nType your message below. Type 'exit' to log out.\nOption 2: Show recently sent messages (Coming Soon)");

        do {
            String[] options = {"Send Message", "Show recently sent messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Messaging Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0: // Send Message
                    String message = JOptionPane.showInputDialog(username + ":");
                    JOptionPane.showMessageDialog(null, "You sent: " + message);
                    break;
                case 1: // Show recent messages
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;
                case 2: // Quit
                    exit = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Try again.");
                    break;
            }

        } while (!exit);

        JOptionPane.showMessageDialog(null, "You have logged out. Goodbye!");
    }
}
