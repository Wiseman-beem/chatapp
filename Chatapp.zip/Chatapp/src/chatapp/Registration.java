package chatapp;

import java.util.Scanner;

public class Registration {
    public static Login registerUser() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        String username = "";
        boolean validUsername = false;
        while (!validUsername) {
            System.out.print("Enter Username: ");
            username = scanner.nextLine();
            if (username.contains("_") && username.length() <= 5) {
                validUsername = true;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        String password = "";
        boolean validPassword = false;
        while (!validPassword) {
            System.out.print("Enter Password: ");
            password = scanner.nextLine();
            if (password.matches("(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=]).{8,}")) {
                validPassword = true;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        String cellNumber = "";
        boolean validCellNumber = false;
        while (!validCellNumber) {
            System.out.print("Enter Cell Phone Number (+27...): ");
            cellNumber = scanner.nextLine();
            if (cellNumber.matches("^\\+27\\d{9}$")) {
                validCellNumber = true;
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            }
        }

        Login login = new Login(username, password, cellNumber, firstName, lastName);
        System.out.println("User registered successfully.");
        return login;
    }
}