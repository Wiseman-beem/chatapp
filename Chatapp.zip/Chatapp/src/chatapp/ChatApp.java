package chatapp;

import java.util.Scanner;

public class ChatApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("--- okay let's do the Registration ---");
        Login login = Registration.registerUser();

    
        System.out.println("\n--- Login in Please ---");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Enter Username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter Password: ");
            String loginPassword = scanner.nextLine();

            String status = login.returnLoginStatus(loginUsername, loginPassword);
            System.out.println(status);

            if (status.contains("Welcome")) {
                loggedIn = true; 
            }
        }
    }
}