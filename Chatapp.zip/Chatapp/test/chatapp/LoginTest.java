package chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    @Test
    public void testCheckUserName() {
        assertTrue(true);
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(true);
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(true);
    }

    @Test
    public void testRegisterUser() {
        assertTrue(true);
    }

    @Test
    public void testLoginUser() {
        assertTrue(true);
    }

    @Test
    public void testReturnLoginStatus() {
        assertTrue(true);
    }
}
